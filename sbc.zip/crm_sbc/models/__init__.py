# -*- coding: utf-8 -*-

from . import models
from . import crm_contacto
from . import crm_trazabilidad
from . import  crm_estado_regularizacion