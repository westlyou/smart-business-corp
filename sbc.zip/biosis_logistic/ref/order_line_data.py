{
 u'procurement_ids': [],
 u'route_id': False,
 u'qty_delivered': 0,
 u'product_id': 3,
 u'product_uom': 1,
 u'sequence': 10,
 u'customer_lead': 0,
 u'price_unit': 200,
 u'product_uom_qty': 1,
 u'discount': 0,
 u'state': u'draft',
 u'qty_delivered_updateable': True,
 u'analytic_tag_ids': [],
 u'invoice_status': u'no',
 u'tax_id': [[6, False, [1]]],
 u'layout_category_id': False,
 u'name': u'20ST Dep\xf3sito (TRAMARSA)'
}
