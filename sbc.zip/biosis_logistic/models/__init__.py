# -*- coding: utf-8 -*-

from . import models
from . import sale_order
from . import product_template
from . import product_product
